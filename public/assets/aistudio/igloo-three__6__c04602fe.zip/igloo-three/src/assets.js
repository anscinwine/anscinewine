import * as THREE from 'three'
import { DRACOLoader } from 'three/examples/jsm/loaders/DRACOLoader.js'
import { KTX2Loader } from 'three/examples/jsm/loaders/KTX2Loader.js'
import { EXRLoader } from 'three/examples/jsm/loaders/EXRLoader.js'

const BASE = '/assets/'

export function createLoaders(renderer, onProgress) {
  const manager = new THREE.LoadingManager()
  manager.onProgress = (_, loaded, total) => onProgress?.(loaded / total)

  const draco = new DRACOLoader(manager).setDecoderPath(BASE + 'libs/draco/')
  draco.preload()

  const ktx2 = new KTX2Loader(manager)
    .setTranscoderPath(BASE + 'libs/basis/')
    .detectSupport(renderer)

  const exr = new EXRLoader(manager)

  const geometry = (name) =>
    new Promise((res, rej) => draco.load(`${BASE}geometries/${name}.drc`, res, undefined, rej))

  // srgb=true cho texture màu, false cho data (noise, AO, normal...)
  const texture = async (name, { srgb = false, repeat = false } = {}) => {
    const t = await ktx2.loadAsync(`${BASE}images/${name}.ktx2`)
    t.anisotropy = renderer.capabilities.getMaxAnisotropy()
    t.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace
    if (repeat) t.wrapS = t.wrapT = THREE.RepeatWrapping
    return t
  }

  const envMap = async (name) => {
    const hdr = await exr.loadAsync(`${BASE}images/${name}.exr`)
    hdr.mapping = THREE.EquirectangularReflectionMapping
    const pmrem = new THREE.PMREMGenerator(renderer)
    const env = pmrem.fromEquirectangular(hdr).texture
    hdr.dispose(); pmrem.dispose()
    return env
  }

  return { geometry, texture, envMap, draco, ktx2 }
}
