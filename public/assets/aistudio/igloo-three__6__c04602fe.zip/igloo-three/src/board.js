import * as THREE from 'three'
import { initMusic } from './music.js'

const OWNER_UTC = 7
// Discord numeric user ID (Settings > Advanced > Developer Mode, then right-click yourself > Copy User ID).
// Once filled in, the Discord button opens your profile directly.
const DISCORD_ID = ''
const tmp = new THREE.Vector3(), tmp2 = new THREE.Vector3()

const fmt = n => (Number.isInteger(n) ? String(n) : n.toFixed(1).replace('.', ','))
const utcLabel = o => 'UTC' + (o >= 0 ? '+' : '−') + fmt(Math.abs(o))
const link = (u, t) => `<a class="lang" href="${u}" target="_blank" rel="noopener">${t}</a>`
const W = 'https://en.wikipedia.org/wiki/'
const langs = `${link(W + 'C%2B%2B', 'C++')}, ${link(W + 'Java_(programming_language)', 'Java')}`
const py = link(W + 'Python_(programming_language)', 'Python'), asm = link(W + 'Assembly_language', 'Assembly')

const STR = {
  en: {
    hello: 'Hello!',
    intro: `I'm 14 and I really like gaming, especially <b>GTA V</b> and <b>Roblox</b>. If you want, you can find me on these platforms:`,
    tzOwn: `My timezone is <b>UTC+7</b>.`,
    learn: `Right now I'm learning ${langs} and ${py}. I also messed around with ${asm} for fun, but it's really hard, so I'll probably drop it soon.`,
    hud: 'Scroll up to get closer', copied: u => `Copied Discord username: ${u}`,
    tzYou: o => `Your timezone is ${utcLabel(o)}.`, tzSame: `We're in the same timezone, not a single hour apart!`,
    tzDiff: (d, ahead) => `We're about ${fmt(Math.abs(d))} hours apart! (you're ${ahead ? 'ahead of me' : 'behind me'})`,
    load_title: 'Loading the snow globe…', load_assets: 'Textures & models', load_tree: 'Christmas tree', load_ui: 'Fonts & interface', load_gpu: 'Shaders & GPU upload', load_total: 'Loading', music_playing: 'Now playing', music_paused: 'Paused · tap to play', music_nofile: 'Tap to open on NhacCuaTui',
  },
  vi: {
    hello: 'Xin chào!',
    intro: `Mình 14 tuổi và rất thích chơi game, nhất là <b>GTA V</b> và <b>Roblox</b>. Nếu muốn, bạn có thể tìm mình trên các nền tảng này:`,
    tzOwn: `Múi giờ của mình là <b>UTC+7</b>.`,
    learn: `Hiện mình đang học ${langs} và ${py}. Mình cũng nghịch thử ${asm} cho vui, nhưng nó khó quá nên chắc sắp bỏ rồi.`,
    hud: 'Cuộn lên để tiến lại gần', copied: u => `Đã copy username Discord: ${u}`,
    tzYou: o => `Múi giờ của bạn là ${utcLabel(o)}.`, tzSame: 'Chúng ta cùng múi giờ, không lệch giờ nào!',
    tzDiff: (d, ahead) => `Chúng ta lệch nhau khoảng ${fmt(Math.abs(d))} tiếng! (bạn ${ahead ? 'sớm hơn' : 'muộn hơn'} mình)`,
    load_title: 'Đang tải quả cầu tuyết…', load_assets: 'Texture & mô hình', load_tree: 'Cây thông Noel', load_ui: 'Font & giao diện', load_gpu: 'Shader & đẩy lên GPU', load_total: 'Đang tải', music_playing: 'Đang phát', music_paused: 'Tạm dừng · bấm để phát', music_nofile: 'Bấm để mở trên NhacCuaTui',
  },
}
let lang = 'en'
try { lang = localStorage.getItem('lang') || 'en' } catch {}
export const tr = (k, ...a) => { const v = STR[lang][k]; return typeof v === 'function' ? v(...a) : v }

// text "decodes" letter by letter into the new language instead of switching at once
function morph(el, html, delay = 0) {
  cancelAnimationFrame(el._raf); el.innerHTML = html
  const nodes = [], w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT)
  while (w.nextNode()) nodes.push(w.currentNode)
  const fin = nodes.map(n => n.nodeValue), total = fin.reduce((a, s) => a + s.length, 0) || 1
  const G = 'abcdefghklmnopqrstuvxyzăâêôơư', DUR = 1300, t0 = performance.now() + delay
  const tick = now => {
    const p = now - t0; let off = 0, done = true
    nodes.forEach((n, ni) => {
      const s = fin[ni]; let out = ''
      for (let i = 0; i < s.length; i++) {
        const c = s[i], at = ((off + i) / total) * DUR * 0.6 + (((off + i) * 37) % 11) / 11 * DUR * 0.3
        if (!/[\p{L}\p{N}]/u.test(c) || p >= at + 250) out += c
        else { done = false; out += G[(Math.floor(now / 55) * 31 + (off + i) * 7) % G.length] }
      }
      n.nodeValue = out; off += s.length
    })
    if (!done) el._raf = requestAnimationFrame(tick)
  }
  el._raf = requestAnimationFrame(tick)
}

function applyLang(animate = false) {
  document.documentElement.lang = lang
  const viewer = -new Date().getTimezoneOffset() / 60, diff = viewer - OWNER_UTC
  const set = (el, html, i) => (animate ? morph(el, html, i * 90) : (el.innerHTML = html))
  document.querySelectorAll('[data-i18n]').forEach((e, i) => set(e, tr(e.dataset.i18n), i))
  set(document.getElementById('tz-you'), tr('tzYou', viewer), 3)
  set(document.getElementById('tz-diff'), diff === 0 ? tr('tzSame') : tr('tzDiff', diff, diff > 0), 4)
  const sw = document.getElementById('langsw')
  sw.setAttribute('aria-checked', String(lang === 'vi')); sw.classList.toggle('vi', lang === 'vi')
}

function setupLangSwitch(onChange) {
  const sw = document.getElementById('langsw')
  sw.addEventListener('click', () => {
    lang = lang === 'en' ? 'vi' : 'en'
    try { localStorage.setItem('lang', lang) } catch {}
    applyLang(true); onChange?.()
  })
}

function setupDiscord() {
  const a = document.getElementById('discord')
  if (DISCORD_ID) { a.href = `https://discord.com/users/${DISCORD_ID}`; return }
  const toast = document.getElementById('toast')   // no ID yet: copy the username and open Discord
  a.addEventListener('click', () => {
    navigator.clipboard?.writeText(a.dataset.copy).catch(() => {})
    toast.textContent = tr('copied', a.dataset.copy)
    toast.classList.add('show'); setTimeout(() => toast.classList.remove('show'), 2200)
  })
}

// Christmas lights around the frame + stockings hanging from the top edge
function buildGarland(el) {
  const ns = 'http://www.w3.org/2000/svg', w = el.offsetWidth, h = el.offsetHeight, P = 26, o = 8, r = 46
  el.querySelector('.garland')?.remove()
  const svg = document.createElementNS(ns, 'svg')
  svg.setAttribute('class', 'garland'); svg.setAttribute('width', w + P * 2); svg.setAttribute('height', h + P * 2)
  svg.style.cssText = `left:${-P}px;top:${-P}px`
  const x0 = P - o, y0 = P - o, rw = w + o * 2, rh = h + o * 2
  const wire = document.createElementNS(ns, 'path')
  wire.setAttribute('d', `M${x0 + r},${y0} H${x0 + rw - r} A${r},${r} 0 0 1 ${x0 + rw},${y0 + r} V${y0 + rh - r} A${r},${r} 0 0 1 ${x0 + rw - r},${y0 + rh} H${x0 + r} A${r},${r} 0 0 1 ${x0},${y0 + rh - r} V${y0 + r} A${r},${r} 0 0 1 ${x0 + r},${y0} Z`)
  wire.setAttribute('fill', 'none'); wire.setAttribute('stroke', '#16301f'); wire.setAttribute('stroke-width', '2.5')
  svg.appendChild(wire)
  const len = wire.getTotalLength(), n = Math.round(len / 40), cols = ['#ff4d5a', '#ffd04d', '#4db8ff', '#ff8ad8', '#6dffa0']
  for (let i = 0; i < n; i++) {
    const p = wire.getPointAtLength((i / n) * len), c = cols[i % cols.length]
    const g = document.createElementNS(ns, 'g'); g.setAttribute('transform', `translate(${p.x},${p.y})`)
    g.innerHTML = `<g class="bulb" style="animation-delay:${(i * 0.27) % 2.4}s;color:${c}"><rect x="-2.5" y="-9" width="5" height="5" rx="1" fill="#1d3a26"/><ellipse cx="0" cy="-1" rx="4.6" ry="6.2" fill="currentColor"/><ellipse cx="-1.5" cy="-3" rx="1.2" ry="2" fill="#fff" opacity=".55"/></g>`
    svg.appendChild(g)
  }
  ;[0.07, 0.2, 0.46, 0.62].forEach((f, i) => {
    const g = document.createElementNS(ns, 'g'); g.setAttribute('transform', `translate(${x0 + rw * f},${y0 + 4})`)
    g.innerHTML = `<g class="sock" style="animation-delay:${i * 0.6}s"><path d="M3 0h18v21l9 8c3 3 2 10-5 11-5 1-9-2-13-6L3 29z" fill="${i % 2 ? '#1f8a4c' : '#d62839'}"/><rect x="0" y="0" width="24" height="8" rx="3" fill="#f4f7fb"/><path d="M3 24l10 8M22 31c3 2 6 5 7 8" stroke="#f4f7fb" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M12 0V-6" stroke="#c9a227" stroke-width="2"/></g>`
    svg.appendChild(g)
  })
  el.appendChild(svg)
}

// DOM board follows a 3D point: small when far, grows as the camera gets closer.
export function initBoard(camera, anchor, endDist) {
  const el = document.getElementById('board')
  const width = el.offsetWidth
  setupDiscord()
  const hud = document.getElementById('hud')
  const refresh = () => { setTimeout(() => buildGarland(el), 1400); hud.textContent = tr('hud') }
  setupLangSwitch(refresh)
  applyLang(); refresh(); document.fonts.ready.then(refresh)
  const music = initMusic(tr)   // font changes the board height

  return function update(t) {
    camera.updateMatrixWorld()
    tmp.copy(anchor).project(camera)
    const dist = camera.position.distanceTo(anchor)
    const H = el.offsetHeight
    const fit = Math.min(1, (innerWidth * 0.94) / width, (innerHeight * 0.9) / H)
    const k = Math.min(1, endDist / dist)
    const s = fit * k
    const x = tmp.x * 0.5 * innerWidth
    const y = -tmp.y * 0.5 * innerHeight + Math.sin(t * 0.9) * 8 * s
    el.style.transform = `translate(-50%,-50%) translate(${x.toFixed(1)}px,${y.toFixed(1)}px) scale(${s.toFixed(4)})`
    el.style.opacity = tmp.z < 1 ? (0.3 + 0.7 * k).toFixed(3) : '0'
    music.update(k)
    el.classList.toggle('show', k > 0.82)      // content only appears once you're close
    const near = k > 0.93
    el.classList.toggle('ready', near)
    el.style.pointerEvents = near ? 'auto' : 'none'
    // info for the snow that falls IN FRONT of the board (it hides the board where it passes)
    tmp2.copy(anchor).applyMatrix4(camera.matrixWorldInverse)
    const front = tmp.z < 1
    return { k, depth: front ? -tmp2.z : 0, x: tmp.x, y: -(-tmp.y),
      hw: ((width * 0.5 + 30) * s) / (innerWidth / 2), hh: ((H * 0.5 + 30) * s) / (innerHeight / 2) }
  }
}
