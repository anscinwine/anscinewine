// Background music: silent from far away, gets louder as the camera gets close to the board.
// Put the mp3 at public/music/snowman.mp3 (NhacCuaTui doesn't allow hot-linking its streams).
const SRC = import.meta.env.BASE_URL + 'music/snowman.mp3'
const NCT = 'https://www.nhaccuatui.com/song/p3q2ScW0CXVE'
const ss = (a, b, x) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t) }

export function initMusic(tr) {
  const card = document.getElementById('player'), stat = card.querySelector('.pstat')
  const a = new Audio(SRC); a.loop = true; a.preload = 'auto'; a.volume = 0; a.muted = true   // muted autoplay is always allowed
  let want = true, ok = true, vol = 0, last = 0, lastUnmute = 0
  const say = k => { stat.dataset.i18n = k; stat.innerHTML = tr(k) }
  const set = on => { card.classList.toggle('playing', on); say(on ? 'music_playing' : ok ? 'music_paused' : 'music_nofile') }
  a.addEventListener('error', () => { ok = false; set(false) })
  a.addEventListener('playing', () => set(true))
  a.addEventListener('pause', () => set(false))
  const play = () => a.play().catch(() => {})
  // 1) start right away (muted, so the browser lets it); 2) unmute the moment the browser allows sound
  const unmute = () => {
    if (!want || !ok) return
    if (a.paused) play()
    if (a.muted) {
      a.muted = false; lastUnmute = performance.now()
      setTimeout(() => { if (a.paused) { a.muted = true; play() } }, 250)   // browser refused sound: stay muted, retry on the next input
    }
  }
  play()
  ;['pointerdown', 'pointerup', 'keydown', 'touchstart', 'touchend', 'click', 'wheel', 'mousemove', 'scroll'].forEach(ev =>
    addEventListener(ev, () => { const n = performance.now(); if (n - last > 700) { last = n; unmute() } }, { passive: true, capture: true }))
  const toggle = () => {
    if (!ok) { open(NCT, '_blank', 'noopener'); return }
    if (performance.now() - lastUnmute < 400) return   // this very click just unlocked the sound
    if (a.paused || a.muted) { want = true; a.muted = false; play() } else { want = false; a.pause() }
  }
  card.addEventListener('click', toggle)
  card.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle() } })
  set(false)
  return k => {                                   // k: 0 (far) .. 1 (arrived)
    vol += (Math.pow(ss(0.3, 1, k), 1.6) - vol) * 0.06
    a.volume = Math.min(1, Math.max(0, vol))
  }
}
