import * as THREE from 'three'
import { createLoaders } from './assets.js'
import { applyCameraAt, ANCHOR, END_DIST } from './camera-path.js'
import { createSnowfall, createSnowfallFront } from './particles.js'
import { createSnowGround } from './snow-ground.js'
import { createTree } from './tree.js'
import { initBoard } from './board.js'

const params = new URLSearchParams(location.search)
const SNOW_SECONDS = Number(params.get('snow')) || 150   // ?snow=20 to test; default 150s = 2.5 min
const GROUND_Y = Number(params.get('groundY')) || 0      // chỉnh nếu mặt đất thật cao/thấp hơn
const DEBUG = params.has('debug')

const canvas = document.getElementById('gl')
const logEl = document.getElementById('log')
const pctEl = document.getElementById('pct')
if (DEBUG) logEl.style.display = 'block'
const log = (...a) => { console.log(...a); logEl.textContent += a.join(' ') + '\n' }

const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' })
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5))
renderer.setSize(innerWidth, innerHeight)
renderer.toneMapping = THREE.ACESFilmicToneMapping
renderer.toneMappingExposure = 1.1
renderer.shadowMap.enabled = false   // shadows were too heavy

const FOG_COLOR = 0x070b12, FOG_DENSITY = 0.009
const scene = new THREE.Scene()
scene.background = new THREE.Color(0x05070b)
scene.fog = new THREE.FogExp2(FOG_COLOR, FOG_DENSITY)

const camera = new THREE.PerspectiveCamera(50, innerWidth / innerHeight, 0.1, 400)

scene.add(new THREE.HemisphereLight(0x9fc4ff, 0x0a0e14, 0.6))
const sun = new THREE.DirectionalLight(0xcfe3ff, 1.4)
sun.position.set(8.2 + 20, 0.4 + 30, -27 + 10)       // same direction as before, but aimed at the tree for crisp shadows
sun.target.position.set(8.2, 0.4, -27)
sun.castShadow = false
sun.shadow.mapSize.set(2048, 2048)
Object.assign(sun.shadow.camera, { left: -7, right: 7, top: 9, bottom: -3, near: 5, far: 80 })
sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.03
sun.shadow.camera.updateProjectionMatrix()
scene.add(sun, sun.target)

// ánh sáng lạnh quanh bảng lơ lửng
const boardLight = new THREE.PointLight(0xaed0ff, 60, 40, 1.6)
boardLight.position.copy(ANCHOR)
scene.add(boardLight)

const snowfall = createSnowfall()
scene.add(snowfall)
// 2nd transparent canvas on top of the board: snow that falls in front of the board hides it
const frontCanvas = document.getElementById('snowfront')
const r2 = new THREE.WebGLRenderer({ canvas: frontCanvas, alpha: true, antialias: false })
r2.setPixelRatio(1); r2.setSize(innerWidth, innerHeight); r2.setClearColor(0x000000, 0)
const scene2 = new THREE.Scene(), snowFront = createSnowfallFront(snowfall)
scene2.add(snowFront)
const snowGround = createSnowGround({ y: GROUND_Y, seconds: SNOW_SECONDS, fogColor: FOG_COLOR, fogDensity: FOG_DENSITY })
scene.add(snowGround.mesh)
const prog = {}   // loading progress per task (0..1)
const loadingEl = document.getElementById('loading')
function setProg(name, v) {
  if (!Number.isFinite(v)) return
  prog[name] = Math.max(prog[name] || 0, Math.min(1, v))
  const row = loadingEl.querySelector(`[data-task="${name}"]`)
  if (row) { row.querySelector('b').textContent = Math.round(prog[name] * 100) + '%'; row.querySelector('i').style.width = prog[name] * 100 + '%' }
  const names = ['assets', 'tree', 'ui', 'gpu'], total = names.reduce((a, n) => a + (prog[n] || 0), 0) / names.length
  pctEl.textContent = Math.round(total * 100) + '%'; loadingEl.querySelector('[data-task="total"] i').style.width = total * 100 + '%'
}
const tree = createTree(GROUND_Y, p => setProg('tree', p), renderer)
scene.add(tree.group)

const updateBoard = initBoard(camera, ANCHOR, END_DIST)

let L = null   // original asset loaders: only created if an /assets folder really exists

function standardMat({ color, ao, env, rough = 0.6, metal = 0.0, tint = 0xffffff }) {
  return new THREE.MeshStandardMaterial({
    map: color ?? null, aoMap: ao ?? null, envMap: env ?? null,
    roughness: rough, metalness: metal, color: tint,
  })
}

async function addMesh(name, material) {
  const geo = await L.geometry(name)
  if (!geo.getAttribute('normal')) geo.computeVertexNormals()
  const mesh = new THREE.Mesh(geo, material)
  scene.add(mesh)
  return mesh
}

const rings = []
const withTimeout = (p, ms) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), ms))])

// A missing /assets folder used to hang the loaders forever (the dev server answers 404s with index.html,
// and the Draco/KTX2 workers then never reply). So check first, and fall back to generated assets.
async function assetsAvailable() {
  try {
    const r = await fetch('/assets/geometries/igloo.drc', { method: 'HEAD' })
    return r.ok && !(r.headers.get('content-type') || '').includes('html')
  } catch { return false }
}

async function loadOriginals() {
  L = createLoaders(renderer, p => setProg('assets', p * 0.9))
  const [env, floorColor] = await Promise.all([
    L.envMap('cubes_env').catch(() => null), L.texture('floor_color', { srgb: true }).catch(() => null),
  ])
  if (env) scene.environment = env
  const snow = standardMat({ tint: 0xdfe9f5, rough: 0.9, env }), floorMat = standardMat({ color: floorColor, rough: 0.95, env })
  const igloo = await addMesh('igloo', snow)
  await Promise.all([addMesh('ground', floorMat), addMesh('floor', floorMat), addMesh('mountain', snow)].map(p => p.catch(e => log('✗ ' + e.message))))
  return !!igloo
}

async function init() {
  let ok = false
  if (await assetsAvailable()) ok = await withTimeout(loadOriginals(), 15000).catch(e => (log('assets: ' + e.message), false))
  setProg('assets', 1)
  await tree.ready.catch(e => log('tree: ' + (e.message ?? e))); setProg('tree', 1)
  await Promise.race([document.fonts.ready, new Promise(r => setTimeout(r, 3000))]); setProg('ui', 1)
  // push every texture to the GPU and compile every shader now, so nothing pops in later
  scene.traverse(o => { const ms = [].concat(o.material || []); ms.forEach(mt => Object.values(mt).forEach(v => v && v.isTexture && renderer.initTexture(v))) })
  setProg('gpu', 0.4)
  applyCameraAt(camera, 0)
  await withTimeout(renderer.compileAsync(scene, camera), 8000).catch(() => {}); setProg('gpu', 0.8)
  renderer.render(scene, camera)
  await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r))); setProg('gpu', 1)
  await new Promise(r => setTimeout(r, 300))
}

// ---- cuộn: camera chạy hết quãng đường là tới chỗ bảng ----
let target = 0, current = 0
const scroller = document.getElementById('scroller')
const hud = document.getElementById('hud')
history.scrollRestoration = 'manual'
const toBottom = () => scrollTo(0, document.documentElement.scrollHeight)
const onScroll = () => {
  const span = Math.max(1, scroller.offsetHeight - innerHeight)
  target = 1 - Math.min(1, Math.max(0, scrollY / span))     // scroll UP = get closer
  hud.classList.toggle('hide', target > 0.02)
}
addEventListener('scroll', onScroll, { passive: true })
toBottom(); onScroll()
addEventListener('load', () => { if (current < 0.01) { toBottom(); onScroll() } })

addEventListener('resize', () => {
  renderer.setSize(innerWidth, innerHeight)
  camera.aspect = innerWidth / innerHeight
  camera.updateProjectionMatrix()
  r2.setSize(innerWidth, innerHeight)
})

const clock = new THREE.Clock()
renderer.setAnimationLoop(() => {
  const t = clock.getElapsedTime()
  current += (target - current) * 0.035
  applyCameraAt(camera, current)
  rings.forEach((r, i) => { r.rotation.y = t * 0.08 * (i % 2 ? -1 : 1) })
  snowfall.material.uniforms.uTime.value = t
  snowfall.material.uniforms.uCam.value.copy(camera.position)
  tree.update(t)
  snowGround.update(t)
  const bi = updateBoard(t)
  for (const mt of [snowfall.material, snowFront.material]) {
    mt.uniforms.uBoard.value.set(bi.x, bi.y, bi.hw, bi.hh); mt.uniforms.uBoardDepth.value = bi.depth
  }
  snowFront.material.uniforms.uTime.value = t; snowFront.material.uniforms.uCam.value.copy(camera.position)
  const arrive = Math.min(1, Math.max(0, (bi.k - 0.88) / 0.12))
  frontCanvas.style.opacity = (1 - arrive * arrive * (3 - 2 * arrive)).toFixed(3)   // fully clear once you arrive
  renderer.render(scene, camera)
  if (arrive < 1) r2.render(scene2, camera)
})

init().catch(e => { console.error(e); log('init error: ' + (e.message ?? e)) }).finally(() => loadingEl.classList.add('done'))
setTimeout(() => loadingEl.classList.add('done'), 30000)   // never stay stuck on the loading screen
