import * as THREE from 'three'

// Individual flakes: each has its own speed, sway and size, and vanishes where it hits the ground.
export function createSnowfall(count = 14000) {
  const geo = new THREE.BufferGeometry()
  const pos = new Float32Array(count * 3), rnd = new Float32Array(count)
  for (let i = 0; i < count; i++) {
    pos[i * 3] = Math.random() * 80; pos[i * 3 + 1] = Math.random() * 34; pos[i * 3 + 2] = Math.random() * 100
    rnd[i] = Math.random()
  }
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3))
  geo.setAttribute('aRnd', new THREE.BufferAttribute(rnd, 1))
  const mat = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false,
    uniforms: { uTime: { value: 0 }, uCam: { value: new THREE.Vector3() }, uBoard: { value: new THREE.Vector4() }, uBoardDepth: { value: 0 }, uMode: { value: 0 }, uPR: { value: Math.min(devicePixelRatio, 2) } },
    vertexShader: /* glsl */`
      uniform float uTime, uPR, uBoardDepth, uMode; uniform vec3 uCam; uniform vec4 uBoard; attribute float aRnd; varying float vA;
      void main() {
        float speed = 0.7 + aRnd * 1.3;
        vec3 p = position;
        p.y = mod(position.y - uTime * speed, 34.0);
        p.x += sin(uTime * (0.3 + aRnd * 0.4) + aRnd * 50.0) * (0.4 + aRnd);
        p.z += cos(uTime * (0.25 + aRnd * 0.3) + aRnd * 30.0) * 0.5;
        float zc = uCam.z - 30.0;
        p.x = mod(p.x - uCam.x + 40.0, 80.0) - 40.0 + uCam.x;       // box follows the camera
        p.z = mod(p.z - zc + 50.0, 100.0) - 50.0 + zc;
        vec4 mv = modelViewMatrix * vec4(p, 1.0);
        gl_PointSize = clamp(uPR * (0.5 + aRnd * 1.1) * (55.0 / -mv.z), 1.0, 12.0 * uPR);
        vA = (0.35 + aRnd * 0.55) * smoothstep(0.0, 0.6, p.y);
        gl_Position = projectionMatrix * mv;
        // flakes between the camera and the board are drawn by the overlay canvas (on top of the board)
        vec2 nd = gl_Position.xy / gl_Position.w;
        bool front = -mv.z < uBoardDepth && abs(nd.x - uBoard.x) < uBoard.z && abs(nd.y - uBoard.y) < uBoard.w;
        vA *= (uMode > 0.5) ? (front ? smoothstep(1.0, 2.5, p.y) : 0.0) : (front ? 0.0 : 1.0);
      }`,
    fragmentShader: /* glsl */`
      varying float vA;
      void main() {
        float d = length(gl_PointCoord - 0.5);
        float a = (smoothstep(0.5, 0.28, d) * 0.7 + smoothstep(0.2, 0.0, d) * 0.5) * vA;
        if (a < 0.01) discard;
        gl_FragColor = vec4(0.95, 0.98, 1.0, a);
      }`,
  })
  const pts = new THREE.Points(geo, mat)
  pts.frustumCulled = false
  return pts
}

// same flakes, drawn on a second transparent canvas above the board
export function createSnowfallFront(pts) {
  const m = pts.material.clone(); m.uniforms.uMode.value = 1
  const f = new THREE.Points(pts.geometry, m); f.frustumCulled = false
  return f
}
