# igloo-three

Code mới viết (không phải code gốc igloo.inc).

## Chạy
1. Copy thư mục `assets` vào `public/assets` (geometries/, images/, libs/draco, libs/basis).
2. `npm install` && `npm run dev` -> http://localhost:8080

## Tham số URL
- `(snow is now fully thick from the start)
- `?groundY=1.5` nâng/hạ lớp tuyết nếu mặt đất thật không nằm ở y=0
- `?debug`  hiện log load mesh

## Chỉnh nhanh
- `src/camera-path.js`: ANCHOR (vị trí bảng), keyframe camera
- `src/board.js`: OWNER_UTC (múi giờ của bạn), logic bảng
- `index.html`: nội dung bio + link mạng xã hội
Music: public/music/snowman.mp3 (already included).
