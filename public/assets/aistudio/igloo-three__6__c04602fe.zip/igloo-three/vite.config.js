import { defineConfig } from 'vite'

export default defineConfig({
  // Copy toàn bộ thư mục assets gốc vào public/assets
  publicDir: 'public',
  build: { target: 'es2020', chunkSizeWarningLimit: 1500 },
})
